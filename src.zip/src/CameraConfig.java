

public class CameraConfig {
    public static double getXAngle(double rawA, double dis, double cameraOffset){
        return Math.acos(cameraOffset / dis) - rawA;
    }
    public static double getYAngle(double rawA, double dHeight, double dis){
        return Math.atan2(dHeight, dis) - rawA;
    }
	/**
	 * Configures the horizontal and vertical angles of the CVCamera
	 * 
	 * @param target   the target used to configure the robot. The center of the
	 *                 robot must be perfectly aligned with the given target
	 * @param distance the distance between the robot and the target
	 * @throws java.lang.Exception To configure, the CVCamera must only be able to
	 *         see one valid sighting.
	 */
	/*public void configure(VisionTarget target, double distance) throws Exception {
		if (activeTargets.get(target).sightingCount() != 1)
			throw new Exception("CVCamera must only see one target to perform configuration!");
		if (!activeTargets.get(target).getSightings().get(0).cameraBasedYaw.isPresent()
				|| !activeTargets.get(target).getSightings().get(0).cameraBasedPitch.isPresent())
			throw new Exception("Raw vertical angle or raw horizontal angle is not available!");
		horizontalAngle = CameraConfig.getXAngle(
				activeTargets.get(target).getSightings().get(0).cameraBasedYaw.getAsDouble(), distance,
				horizontalOffset);
		verticalAngle = CameraConfig.getYAngle(
				activeTargets.get(target).getSightings().get(0).cameraBasedPitch.getAsDouble(),
				target.height - verticalOffset, distance);
	}*/
}
