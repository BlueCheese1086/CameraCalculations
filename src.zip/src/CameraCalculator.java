

import java.util.ArrayList;
import java.util.OptionalDouble;

public class CameraCalculator {

	private ArrayList<Sighting> rawSightings = new ArrayList<>();// Raw, unfiltered, unprocessed sightings
	private ArrayList<Sighting> processedSightings = new ArrayList<>();// Filtered, processed, valid sightings
	private Camera camera;
	private VisionTarget visionTarget;

	/**
	 * Creates the CVCamera calculator
	 * 
	 * @param c the CVCamera the calculator uses to get its image data
	 * @param v the vision target it finds
	 */
	public CameraCalculator(Camera c, VisionTarget v) {
		this.camera = c;
		this.visionTarget = v;
	}

	/**
	 * Updates the data from the CVCamera
	 * 
	 * @param polys the data from the CVCamera
	 */
	void updateObjects(ArrayList<Sighting> polys) {
		//TODO GET RID OF ZOLA SPECIFIC CODE (240-)
		rawSightings.clear();
		rawSightings.addAll(polys);
		rawSightings = visionTarget.validateRawSightings(rawSightings);
		calculateCameraBasedDistance();
		calculateAngle();
		calculateRotation();
		processedSightings = visionTarget.validateProcessedSightings(new ArrayList<>(rawSightings));
		processedSightings = new ArrayList<>(rawSightings);
	}

	/**
	 * Calculates the distance to the specified vision target
	 */
	public void calculateCameraBasedDistance() {
		for (Sighting sighting : rawSightings) {
			double cameraBasedPitch = getYAngle(240.0-sighting.getCenterY());
			System.out.println("centery "+ sighting.getCenterY());
			sighting.setCameraBasedPitch(cameraBasedPitch);
			double robotBasedPitch = cameraBasedPitch + camera.getVerticalAngle();
			double changeInHeight = visionTarget.getHeight() - camera.getVerticalOffset();
			System.out.println("RobotPitch"+robotBasedPitch+ " height "+ changeInHeight);
			double distanceToTarget = changeInHeight / Math.sin(robotBasedPitch);
			double horizontalDistance = distanceToTarget * Math.cos(robotBasedPitch);
			sighting.setCameraBasedDistance(horizontalDistance);
		}
	}

	/**
	 * Calculates the angle to the specified vision target
	 */
	public void calculateAngle() {
		// This math is based off of representing the sighting, horizontal center of the
		// robot, and camera as 3 points on a triangle.
		// Using the laws of sines and cosines, we can account for the horizontal shift
		// in the camera and find the angle of the sighting
		// relative to the center of the robot.
		// Angle names such as "angleFromSighting" represent the angle of the triangle
		// at the point specified (Sighting in the example)
		for (Sighting p : rawSightings) {
			p.setCameraBasedYaw(getXAngle(p.getCenterX()));
			System.out.println("X angle " + Math.toDegrees(p.getCameraBasedYaw().getAsDouble()));
			double angleFromCamera = p.getCameraBasedYaw().getAsDouble() - camera.getHorizontalAngle()
					- Math.signum(camera.getHorizontalOffset()) * Math.PI / 2.0;
			System.out.println("Angle from Camera " + Math.toDegrees(angleFromCamera));
			double distance = p.getCameraBasedDistance().getAsDouble();
			System.out.println("Camera-based distance "+ distance);
			// law of cosines
			double robotBasedDistance = Math
					.sqrt(distance * distance + camera.getHorizontalOffset() * camera.getHorizontalOffset()
							- 2.0 * distance * Math.abs(camera.getHorizontalOffset()) * Math.cos(angleFromCamera));
			System.out.println("Robot-based distance " + robotBasedDistance);
			p.setRobotBasedDistance(robotBasedDistance);
			// law of sines
			double angleFromSighting = Math
					.asin(camera.getHorizontalOffset() * Math.sin(angleFromCamera) / robotBasedDistance);
			System.out.println("angleFromSighting "+Math.toDegrees(angleFromSighting));
			// sum of the angles in a triangle is pi
			double angleFromRobot = Math.PI - angleFromCamera - angleFromSighting;
			System.out.println("angleFromRobot "+Math.toDegrees(angleFromRobot));

			// transform the angle so that 0 is in front of the robot, not out of view
			if (camera.getHorizontalOffset()!=0) {
				
			
			p.setRobotBasedYaw(Math.PI / 2.0-angleFromRobot);
			} else {
				p.setRobotBasedYaw((Math.PI-angleFromRobot));	
			}
			System.out.println("Final Yaw Output "+ Math.toDegrees(p.getRobotBasedYaw().getAsDouble()));
		}
	}

	/**
	 * Calculates the horizontal rotation of the vision target relative to the
	 * CVCamera
	 */
	public void calculateRotation() {
		for (Sighting s : rawSightings) {
			s.setRelativeAspectRatio(s.getAspectRatio() / visionTarget.getAspectRatio());
			if (Math.abs(s.getRelativeAspectRatio().getAsDouble()) < 1) {
				s.setRobotBasedRotation(Math.acos(s.getRelativeAspectRatio().getAsDouble()));
			} else {
				s.setRobotBasedRotation(0);
			}
		}
	}

	/**
	 * Finds the horizontal angle to a specific pixel on the CVCamera
	 * 
	 * @param x the pixel
	 * @return the angle
	 */
	public double getXAngle(double x) {
		// uses pinhole model of camera to find angle
		double horizontalFocalLength = (camera.getPixelWidth() / 2.0) / Math.tan(camera.getHorizontalFOV() / 2.0);
		double centerX = (camera.getPixelWidth() / 2.0) - 0.5;// -.5 accounts for 0 being lowest pixel value and
																// (pixelWidth-1) being the highest
		return Math.atan((centerX - x) / horizontalFocalLength);
	}

	/**
	 * Finds the vertical angle to a specific pixel on the CVCamera
	 * 
	 * @param y the pixel
	 * @return the angle
	 */
	public double getYAngle(double y) {
		// uses pinhole model of camera to find angle
		double verticalFocalLength = (camera.getPixelHeight() / 2.0) / Math.tan(camera.getVerticalFOV() / 2.0);
		System.out.println("vfov"+ camera.getVerticalFOV());
		double centerY = (camera.getPixelHeight() / 2.0) - 0.5;// -.5 accounts for 0 being lowest pixel value and
																// (pixelHeight-1) being the highest
		System.out.println("VALUE "+centerY+ " " + y+" "+verticalFocalLength+" "+ camera.getVerticalFOV());
		return Math.atan((centerY - y) / verticalFocalLength);
	}

	/**
	 * Returns the most recent target sightings from the given camera
	 * 
	 * @return a list of all the sightings
	 */
	public ArrayList<Sighting> getSightings() {
		return new ArrayList<>(processedSightings);
	}

	/**
	 * returns the number of sightings of this target from this camera
	 * 
	 * @return the number of sightings of this target from this camera
	 */
	public int sightingCount() {
		return processedSightings.size();
	}
}